<?php
/*
Plugin Name: WP Login Timeout
Description: Set custom login session timeout for users from the dashboard.
Version: 1.0
Author: Rakib
*/

// Include settings
require_once plugin_dir_path(__FILE__) . 'settings.php';

// Set custom session timeout
add_filter('auth_cookie_expiration', 'custom_session_timeout', 99, 3);
function custom_session_timeout($expire, $user_id, $remember) {
    $custom_timeout = get_option('custom_login_timeout');
    return ($custom_timeout && is_numeric($custom_timeout)) ? intval($custom_timeout) : $expire;
}
