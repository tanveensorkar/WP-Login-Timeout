<?php
// Add settings menu
add_action('admin_menu', 'login_timeout_settings_menu');
function login_timeout_settings_menu() {
    add_options_page(
        'Login Timeout Settings',
        'Login Timeout',
        'manage_options',
        'login-timeout-settings',
        'login_timeout_settings_page'
    );
}

// Register setting
add_action('admin_init', function() {
    register_setting('login-timeout-group', 'custom_login_timeout');
});

function login_timeout_settings_page() {
    ?>
    <div class="wrap">
        <h2>Login Timeout Settings</h2>
        <form method="post" action="options.php">
            <?php settings_fields('login-timeout-group'); ?>
            <?php do_settings_sections('login-timeout-group'); ?>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">Session Timeout (in seconds)</th>
                    <td><input type="number" name="custom_login_timeout" value="<?php echo esc_attr(get_option('custom_login_timeout', 3600)); ?>" /></td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}
